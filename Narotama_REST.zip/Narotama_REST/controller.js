'use strict';
var response = require('./res');
var connection = require('./conn');

exports.findUsers = function(req, res){
    // var id = req.params.id;
    connection.query('SELECT * FROM datapemantauan',

    function(error, rows, fields){
    if(error){
        console.log(error)}
        else{
            response.ok(rows, res)
        }
    });
};  